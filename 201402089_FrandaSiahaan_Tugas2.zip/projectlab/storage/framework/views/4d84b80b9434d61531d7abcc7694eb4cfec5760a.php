

<?php $__env->startSection('container'); ?>

    <main>      
        <div class="container mt-5">
            

            <div class="container">
                <div class="row justify-content-start">
                    <h2>Grid 1</h2>
                        <div class="col-12 col-md-6 col-lg-1 bg-primary text-white p-1 rounded">
                        kolom 1
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-secondary text-white p-1 rounded">
                        kolom 2
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-success text-white p-1 rounded">
                        kolom 3
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-warning text-white p-1 rounded">
                        kolom 4
                        </div>
                </div>
                <div class="row justify-content-end">
                    <h2 class="mt-3">Grid 2</h2>
                        <div class="col-12 col-md-6 col-lg-1 bg-primary text-white p-1 rounded">
                        kolom 1
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-secondary text-white p-1 rounded">
                        kolom 2
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-success text-white p-1 rounded">
                        kolom 3
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-warning text-white p-1 rounded">
                        kolom 4
                        </div>
                </div>
                <div class="row justify-content-center">
                    <h2 class="mt-3">Grid 3</h2>
                        <div class="col-12 col-md-6 col-lg-1 bg-primary text-white p-1 rounded">
                        kolom 1
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-secondary text-white p-1 rounded">
                        kolom 2
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-success text-white p-1 rounded">
                        kolom 3
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-warning text-white p-1 rounded">
                        kolom 4
                        </div>
                </div>
                <div class="row justify-content-between">
                    <h2 class="mt-3">Grid 4</h2>
                        <div class="col-12 col-md-6 col-lg-1 bg-primary text-white p-1 rounded">
                        kolom 1
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-secondary text-white p-1 rounded">
                        kolom 2
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-success text-white p-1 rounded">
                        kolom 3
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-warning text-white p-1 rounded">
                        kolom 4
                        </div>
                </div>
                <div class="row justify-content-around">
                    <h2 class="mt-3">Grid 5</h2>
                        <div class="col-12 col-md-6 col-lg-1 bg-primary text-white p-1 rounded">
                        kolom 1
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-secondary text-white p-1 rounded">
                        kolom 2
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-success text-white p-1 rounded">
                        kolom 3
                        </div>
                        <div class="col-12 col-md-6 col-lg-1 bg-warning text-white p-1 rounded">
                        kolom 4
                        </div>
                </div>
                
                <div class="row justify-content-between">
                    <h2 class="mt-3">Grid 6</h2>
                        <div class="col-12 col-md-6 col-lg-1 bg-primary text-white p-1 rounded">
                        kolom 1
                        </div>
                        <div class="col-12 col-md-6 col-lg-2 bg-secondary text-white p-1 rounded">
                        kolom 2
                        </div>
                        <div class="col-12 col-md-6 col-lg-3 bg-success text-white p-1 rounded">
                        kolom 3
                        </div>
                        <div class="col-12 col-md-6 col-lg-4 bg-warning text-white p-1 rounded">
                        kolom 4
                        </div>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.tugas1lyot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pwl-laravel\projectlab\resources\views/tugas1.blade.php ENDPATH**/ ?>