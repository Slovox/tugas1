

<?php $__env->startSection('header','Yang Baca Ini Wibu !'); ?>

<?php $__env->startSection('teks'); ?>

    <?php if($nama == "Kak_Ara"): ?>
        <h2>Selamat datang Kak Ara yang cantik dan baik hati</h2>
    <?php elseif($nama == "Cantik"): ?>
        <h2>Kak Ara yang cantik dan baik hati, saya tidak bisa menjelaskan lagi...</h2>
    <?php else: ?>
        <h2>Berikan nilai terbaik untuk tugas saya ini ya kak</h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.lab1lyot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\pwl-laravel\project\resources\views/lab1.blade.php ENDPATH**/ ?>